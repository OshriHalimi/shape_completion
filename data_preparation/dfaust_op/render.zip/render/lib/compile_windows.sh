#!/usr/bin/env bash


# export CUDA_LIB="'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v9.0\lib\x64'"
# export CUDA_INCLUDE="'C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v9.0\include'"
# export CFLAGS="-I$PWD -I$GLM_INCLUDE -I$CUDA_INCLUDE -I$CUDA_LIB"
# export DFLAGS="-L$CUDA_LIB"

export GLM_INCLUDE="./glm"


# build source
# nvcc -c main.cpp -I$GLM_INCLUDE -O2  
# nvcc -c buffer.cpp -I$GLM_INCLUDE -O2 
nvcc -c render.cu -I$GLM_INCLUDE  -O2 
# -D_FORCE_INLINES
# test buffer
nvcc main.obj buffer.obj render.obj -I$GLM_INCLUDE -O2 -o libRender.dll -shared -lcudart  
#  libRender.so

#g++ -std=c++11 main.o buffer.o loader.o render.o $CFLAGS $DFLAGS -o render -lcudart

#rm *.o
